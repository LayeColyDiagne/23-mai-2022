<?php
/*
 * typedemandeservice.php
 */
require_once 'models/typedemandeentity.php';
require_once 'dal/typedemandedao.php';

class TypeDemandeService {
    public function gettypedemandelist() {
        $dao = new TypeDemandeDAO();
        return $dao->gettypedemandelist();
    }
}

?>
