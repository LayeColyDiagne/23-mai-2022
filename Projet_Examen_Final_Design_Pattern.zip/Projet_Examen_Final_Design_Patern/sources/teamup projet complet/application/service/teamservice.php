<?php
/*
 * teamservice.php
 */
require_once 'models/teamentity.php';
require_once 'dal/teamdao.php';

class TeamService {
    public function getteamlist(){
        $teamdao = new TeamDAO();
        return $teamdao->getteamlist();
    }
    
    public function addteam(TeamEntity $team) {
        $teamdao = new TeamDAO();
        $teamdao->addteam($team);
    }
    
    public function editteam(TeamEntity $team) {
        $teamdao = new TeamDAO();
        $teamdao->editteam($team);
    }
  
    public function getuserteam($id_equipe) {
        $teamdao = new TeamDAO();
        return $teamdao->getuserteam($id_equipe);
    }
    
    public function adduserteam($id_utilisateur,$id_equipe) {
        $teamdao = new TeamDAO();
        $teamdao->adduserteam($id_utilisateur, $id_equipe);
    }
    
    public function removeuserteam($id_utilisateur,$id_equipe) {
        $teamdao = new TeamDAO();
        $teamdao->removeuserteam($id_utilisateur, $id_equipe);
    }
    
    public function getusernotinteam($id_equipe) {
        $teamdao = new TeamDAO();
        return $teamdao->getusernotinteam($id_equipe);
    }
}
?>