<?php
/*
 * sendgridservice.php
 */
require_once 'config.php';

class SendGridService {
    public function sendmessage($from,$to,$subject,$html) 
    {
        $credentials= get_sendgrid_credentials();
        $url = 'https://api.sendgrid.com/';
        $user = $credentials["username"];
        $pass = $credentials["password"];
        
        $params = array(
            'api_user' => $user,
            'api_key' => $pass,
            'to' => $to,
            'subject' => $subject,
            'html' => $html,
            'text' => $html,
            'from' => $from,
        );
        
        $request = $url.'api/mail.send.json';
        
        $http_session = curl_init($request);
        echo $http_session."<br>";
        
        curl_setopt ($http_session, CURLOPT_POST, true);
        curl_setopt ($http_session, CURLOPT_POSTFIELDS, $params);

        curl_setopt($http_session, CURLOPT_SSLVERSION, 6);
        curl_setopt($http_session, CURLOPT_SSL_VERIFYPEER, false);
        
        curl_setopt($http_session, CURLOPT_HEADER, false);
        curl_setopt($http_session, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($http_session);
        curl_close($http_session);
        
        echo $request."<br>";
        echo "<br>".$response."<br>";
    }
}

?>