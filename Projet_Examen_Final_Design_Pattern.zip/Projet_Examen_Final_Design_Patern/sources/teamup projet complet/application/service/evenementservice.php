<?php
/*
 * evenementservice.php
 */

require_once 'models/evenemententity.php';
require_once 'models/participantentity.php';
require_once 'dal/evenementdao.php';

class EvenementService {
    /**
     * 
     * @var EvenementDAO
     */
    private $dao; 
    function __construct() {
        $this->dao = new EvenementDAO();
    }

    public function evenement_add(EvenementEntity $ev, array $pe=null) {
        return $this->dao->evenement_add($ev, $pe);
    }
    
    public function evenement_set_participant($id_evenement,array $pe)
    {
        $this->dao->evenement_set_participant($id_evenement, $pe);
    }
    
    public  function evenement_get_participant($id_evenement)
    {
        return $this->dao->evenement_get_participant($id_evenement);
    }
    
    public function evenement_get_by_id($id_evenement)
    {
        return $this->dao->evenement_get_by_id($id_evenement);
    }
    
    public function evenement_edit(EvenementEntity $ev, array $pe=null)
    {
        $this->dao->evenement_edit($ev,$pe);
    }
    
    public function evenement_get_from_utilisateur($id_utilisateur) 
    {
        return $this->dao->evenement_get_from_utilisateur($id_utilisateur);
    }
    
    public function evenement_get_from_dates($dtstart,$dtend) 
    {
        return $this->dao->evenement_get_from_dates($dtstart, $dtend);
    }
    
    public function evenement_get_from_dates_utilisateur($dtstart, $dtend, $id_utilisateur)
    {
        return $this->dao->evenement_get_from_dates_utilisateur($dtstart, $dtend, $id_utilisateur);
    }
}

?>