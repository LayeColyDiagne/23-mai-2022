<?php

/*
 * messageservice.php
 */
    
class MessageService
{
    public function recordMessage(MessageEntity $msg) {
        $client = new \MongoDB\Client("mongodb://localhost:27017");
        $collection = $client->teamup->chat;
        
        $collection->insertOne( [ 'from' => $msg->from, 
            'attendee' => $msg->attendee, 
            'message' => $msg->message, 
            'date' => $msg->date
        ]);
    }
    
    public function new_guid()
    {
        if (function_exists('com_create_guid')){
            \TraceListener::write_message("com_create_guid existe, OS = windows",TraceLevel::LEVEL_INFO);
            return com_create_guid();
        }else{
            mt_srand((double)microtime()*10000);
            $charid = strtoupper(md5(uniqid(rand(), true)));
            $hyphen = chr(45);// "-"
            $uuid = "" 
            //chr(123)// "{"
            .substr($charid, 0, 8).$hyphen
            .substr($charid, 8, 4).$hyphen
            .substr($charid,12, 4).$hyphen
            .substr($charid,16, 4).$hyphen
            .substr($charid,20,12)
            //.chr(125) // "}"
            ;
            return $uuid;
        }
    }
    
    public function getBlob($content_name) 
    {
        $client = new \MongoDB\Client("mongodb://localhost:27017");
        $video = $client->teamup->video;
        $blob = $client->teamup->blob;
        
        $content = array();
        $c_content = $video->find(['content_name' => $content_name]);
        foreach ($c_content as $doc) 
        {
            $content_data = "";
            $blobref = $doc['content_blob']; 
            foreach($blobref as $id)
            {
               $c_blob = $blob->find(['_id' => $id]);
               foreach($c_blob as $b)
               {
                   $chunk = $b['chunk_data'];
                   $content_data .= $chunk;
               }
            }
            
            $content['content_name'] = $doc['content_name'];
            $content['content_date'] = $doc['content_date'];
            $content['content_type'] = $doc['content_type'];
            $content['content_length'] = $doc['content_length'];
            $content['content_data'] = base64_decode($content_data);
        }
        return $content;
    }
    
    public function putBlob($content_name, $content_type, $content_date, $content_data, $content_length)
    {
        $client = new \MongoDB\Client("mongodb://localhost:27017");
        $video = $client->teamup->video;
        $blob = $client->teamup->blob;
        
        $data = base64_encode($content_data);
        
        $filename = 'php://memory';
        $stream = fopen($filename, "w+b");
        fwrite($stream, $data);
        rewind($stream);
        
        $i = 0;
        $count = strlen($data);
        $blobref = array();
        $buffersize = 16000000;
        $index = 0;
        $chunk_array = array();
        
        while(!feof($stream) && $i <= $count)
        {
            $bytesToRead = $buffersize;
            if(($i+$bytesToRead) > $count)
            {
                $bytesToRead = $count - $i + 1;
            }
            
            $chunk = fread($stream, $bytesToRead);
            
            $chunk_array["_id"] = $this->new_guid();
            $chunk_array['chunk_data'] = $chunk;
            $chunk_array['chunk_index'] = $index;
            
            $blob->insertOne($chunk_array);
            
            $blobref[] = $chunk_array["_id"];
            $i += $bytesToRead;
            $index++;
        }
        fclose($stream);
        
        $video->insertOne( 
            [ 
                'content_name' => $content_name,
                'content_type' => $content_type,
                'content_date' => $content_date,
                'content_blob' => $blobref,
                'content_length' => $content_length,
            ]);
    }
    
    public function search($username, $text) 
    {
        $client = new \MongoDB\Client("mongodb://localhost:27017");
        $chat = $client->teamup->chat;
        
        $result = array();
        $c_res = $chat->find(
            [
                '$text'=> ['$search' => $text." ".$username]
                
            ]);
        foreach($c_res as $doc)
        {
            $rdoc = array();
            $rdoc['from'] = $doc['from'];
            $rdoc['attendee'] = $doc['attendee'];
            $rdoc['message'] = $doc['message'];
            $rdoc['date'] = $doc['date'];
            
            $result[] = $rdoc;
        }
        
        return $result;
    }
}
?>