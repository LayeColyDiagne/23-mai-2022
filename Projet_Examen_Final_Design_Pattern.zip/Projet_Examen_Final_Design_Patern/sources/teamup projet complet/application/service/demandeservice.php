<?php
/*
 * demandeservice.php
 */

require_once 'models/demandeentity.php';
require_once 'dal/demandedao.php';

class DemandeService {
    public function getlistdemandes($id_utilisateur=null){
        $dao = new DemandeDAO();
        return $dao->getlistdemandes($id_utilisateur);
    }
    
    public function adddemande(DemandeEntity $demande) {
        $dao = new DemandeDAO();
        $dao->adddemande($demande);
    }
    
    public function editdemande(DemandeEntity $demande) {
        $dao = new DemandeDAO();
        $dao->editdemande($demande);
    }
    
    public function getdemandebyid($id_demande){
        $dao = new DemandeDAO();
        return $dao->getdemandebyid($id_demande);
    }
}
?>