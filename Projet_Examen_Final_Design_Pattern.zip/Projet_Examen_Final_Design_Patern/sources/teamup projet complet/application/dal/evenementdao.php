<?php
/*
 * evenementdao.php
 */
require_once 'config.php';
require_once 'models/evenemententity.php';
require_once 'models/participantentity.php';

class EvenementDAO {
    private $db_connection;
    
    public function __construct() {
        $this->db_connection = get_default_connection();
    }
    
    public function evenement_add(EvenementEntity $ev, array $pe=null){
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        $date_dtstart = DateTime::createFromFormat('d/m/Y H:i', $ev->evenement_dtstart);
        $dtstart = $date_dtstart->format('Y-m-d H:i:s');
        
        $date_dtend = DateTime::createFromFormat('d/m/Y H:i', $ev->evenement_dtend);
        $dtend = $date_dtend->format('Y-m-d H:i:s');
        
        $date_tstamp = DateTime::createFromFormat('d/m/Y H:i', $ev->evenement_tstamp);
        $tstamp = $date_tstamp->format('Y-m-d H:i:s');
        
        /*
         * `subject` `description` `location` `tstamp` `dtstart` `dtend` `id_utilisateur` 
         */
        
        $query = "call sp_evenement_add(" .
        "'$ev->evenement_subject'," .
        "'$ev->evenement_description'," .
        "'$ev->evenement_location'," .
        
        "'$tstamp'," .
        "'$dtstart'," .
        "'$dtend'," .
       
        "$ev->id_utilisateur" .
            
        ")";
                
        $result = mysqli_query($cx, $query);
            
        $row = mysqli_fetch_array($result);
        mysqli_close($cx);
    
        $id_evenement = $row[0];
        
        $this->evenement_set_participant($id_evenement, $pe);
        return $id_evenement;
    }
    
    public function evenement_set_participant($id_evenement,array $pe)
    {
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        
        $query = "delete from participant where id_evenement=$id_evenement";
        mysqli_query($cx, $query);
        
        foreach($pe as $p) {
            $query = "call sp_evenement_set_participant($id_evenement,$p->id_utilisateur)";
            mysqli_query($cx, $query);
        }
        
        mysqli_close($cx);
    }
    
    public  function evenement_get_participant($id_evenement)
    {
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        // construit la requ�te
        $query = "call sp_evenement_get_participant($id_evenement)";
        
        // ex�cute la requ�te
        $result = mysqli_query($cx, $query);
        
        $list = array();
        while( ($row=mysqli_fetch_assoc($result))!=null) {
            $pe = new ParticipantEntity();
            $pe->id_evenement = $id_evenement;
            $pe->id_utilisateur = $row["id_utilisateur"];
            $list[] = $pe;
        }
        
        // lib�re la ressource SQL
        mysqli_free_result($result);
        mysqli_close($cx);
        
        return $list;
    }
    
    public function evenement_get_by_id($id_evenement) 
    {
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        // construit la requ�te
        $query = "call sp_evenement_by_id($id_evenement)";
        
        // ex�cute la requ�te
        $result = mysqli_query($cx, $query);
        
        $list = array();
        while( ($row=mysqli_fetch_assoc($result))!=null) {
            $ev = new EvenementEntity();
            $ev->id_evenement = $id_evenement;
            $ev->evenement_description = $row["evenement_description"];
            $ev->evenement_subject = $row["evenement_subject"];
            $ev->evenement_location = $row["evenement_location"];
            $ev->id_utilisateur = $row["evenement_id_utilisateur"];
            
            $date_dtstart= DateTime::createFromFormat('Y-m-d H:i:s', $row["evenement_dtstart"]);
            $ev->evenement_dtstart = $date_dtstart->format('d/m/Y H:i');
            
            $date_dtend= DateTime::createFromFormat('Y-m-d H:i:s', $row["evenement_dtend"]);
            $ev->evenement_dtend = $date_dtend->format('d/m/Y H:i');
            
            $date_tstamp= DateTime::createFromFormat('Y-m-d H:i:s', $row["evenement_tstamp"]);
            $ev->evenement_tstamp = $date_tstamp->format('d/m/Y H:i');
            
            $list[] = $ev;
        }
        
        // lib�re la ressource SQL
        mysqli_free_result($result);
        mysqli_close($cx);
        
        return $list[0];
    }
    
    /**
     * Edit evenement
     * @param EvenementEntity $ev
     * @param array ParticipantEntity $pe
     */
    public function evenement_edit(EvenementEntity $ev, array $pe=null) 
    {
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        $date_dtstart = DateTime::createFromFormat('d/m/Y H:i', $ev->evenement_dtstart);
        $dtstart = $date_dtstart->format('Y-m-d H:i:s');
        
        $date_dtend = DateTime::createFromFormat('d/m/Y H:i', $ev->evenement_dtend);
        $dtend = $date_dtend->format('Y-m-d H:i:s');
                
        /*
         * id_ev dtstart dtend `subject` `description` `location` `id_utilisateur`
         */
        
        $query = "call sp_evenement_edit(" .
            "$ev->id_evenement," . 
            
            "'$dtstart'," .
            "'$dtend'," .
            
            "'$ev->evenement_subject'," .
            "'$ev->evenement_description'," .
            "'$ev->evenement_location'," .
            
            "$ev->id_utilisateur" .
            
            ")";
        
        mysqli_query($cx, $query);
        
        mysqli_close($cx);
        
        $this->evenement_set_participant($ev->id_evenement, $pe);
    }
    
    public function evenement_get_from_utilisateur($id_utilisateur) 
    {
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        // construit la requ�te
        $query = "call sp_evenement_from_utilisateur($id_utilisateur)";
        
        // ex�cute la requ�te
        $result = mysqli_query($cx, $query);
        
        $list = array();
        while( ($row=mysqli_fetch_assoc($result))!=null) {
            $ev = new EvenementEntity();
            $ev->id_evenement = $row["id_evenement"];
            $ev->evenement_description = $row["evenement_description"];
            $ev->evenement_subject = $row["evenement_subject"];
            $ev->evenement_location = $row["evenement_location"];
            $ev->id_utilisateur = $id_utilisateur;
            
            $date_dtstart= DateTime::createFromFormat('Y-m-d H:i:s', $row["evenement_dtstart"]);
            $ev->evenement_dtstart = $date_dtstart->format('d/m/Y H:i');
            
            $date_dtend= DateTime::createFromFormat('Y-m-d H:i:s', $row["evenement_dtend"]);
            $ev->evenement_dtend = $date_dtend->format('d/m/Y H:i');
            
            $date_tstamp= DateTime::createFromFormat('Y-m-d H:i:s', $row["evenement_tstamp"]);
            $ev->evenement_tstamp = $date_tstamp->format('d/m/Y H:i');
            
            $list[] = $ev;
        }
        
        // lib�re la ressource SQL
        mysqli_free_result($result);
        mysqli_close($cx);
        
        return $list;
    } 
    
    public function evenement_get_from_dates($dtstart,$dtend) 
    {
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        // construit la requ�te
        $date_dtstart= DateTime::createFromFormat('d/m/Y', $dtstart);
        $evenement_dtstart = $date_dtstart->format('Y-m-d');
        
        $date_dtend= DateTime::createFromFormat('d/m/Y', $dtend);
        $evenement_dtend = $date_dtend->format('Y-m-d');
        
        $query = "call sp_evenement_from_dates('$evenement_dtstart','$evenement_dtend')";
        
        // ex�cute la requ�te
        $result = mysqli_query($cx, $query);
        
        $list = array();
        while( ($row=mysqli_fetch_assoc($result))!=null) {
            $ev = new EvenementEntity();
            $ev->id_evenement = $row["id_evenement"];
            $ev->evenement_description = $row["evenement_description"];
            $ev->evenement_subject = $row["evenement_subject"];
            $ev->evenement_location = $row["evenement_location"];
            $ev->id_utilisateur = $row["evenement_id_utilisateur"];
            
            $date_dtstart= DateTime::createFromFormat('Y-m-d H:i:s', $row["evenement_dtstart"]);
            $ev->evenement_dtstart = $date_dtstart->format('d/m/Y H:i');
            
            $date_dtend= DateTime::createFromFormat('Y-m-d H:i:s', $row["evenement_dtend"]);
            $ev->evenement_dtend = $date_dtend->format('d/m/Y H:i');
            
            $date_tstamp= DateTime::createFromFormat('Y-m-d H:i:s', $row["evenement_tstamp"]);
            $ev->evenement_tstamp = $date_tstamp->format('d/m/Y H:i');
            
            $list[] = $ev;
        }
        
        // lib�re la ressource SQL
        mysqli_free_result($result);
        mysqli_close($cx);
    
        return $list;
    }
    
    public function evenement_get_from_dates_utilisateur($dtstart, $dtend, $id_utilisateur)
    {
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        // construit la requ�te
        $date_dtstart= DateTime::createFromFormat('d/m/Y', $dtstart);
        $evenement_dtstart = $date_dtstart->format('Y-m-d');
        
        $date_dtend= DateTime::createFromFormat('d/m/Y', $dtend);
        $evenement_dtend = $date_dtend->format('Y-m-d');
        
        $query = "call sp_evenement_from_dates_utilisateur('$evenement_dtstart','$evenement_dtend',$id_utilisateur)";
        
        // ex�cute la requ�te
        $result = mysqli_query($cx, $query);
        
        $list = array();
        while( ($row=mysqli_fetch_assoc($result))!=null) {
            $ev = new EvenementEntity();
            $ev->id_evenement = $row["id_evenement"];
            $ev->evenement_description = $row["evenement_description"];
            $ev->evenement_subject = $row["evenement_subject"];
            $ev->evenement_location = $row["evenement_location"];
            $ev->id_utilisateur = $row["evenement_id_utilisateur"];
            
            $date_dtstart= DateTime::createFromFormat('Y-m-d H:i:s', $row["evenement_dtstart"]);
            $ev->evenement_dtstart = $date_dtstart->format('d/m/Y H:i');
            
            $date_dtend= DateTime::createFromFormat('Y-m-d H:i:s', $row["evenement_dtend"]);
            $ev->evenement_dtend = $date_dtend->format('d/m/Y H:i');
            
            $date_tstamp= DateTime::createFromFormat('Y-m-d H:i:s', $row["evenement_tstamp"]);
            $ev->evenement_tstamp = $date_tstamp->format('d/m/Y H:i');
            
            $list[] = $ev;
        }
        
        // lib�re la ressource SQL
        mysqli_free_result($result);
        mysqli_close($cx);
        
        return $list;
    }
}
?>