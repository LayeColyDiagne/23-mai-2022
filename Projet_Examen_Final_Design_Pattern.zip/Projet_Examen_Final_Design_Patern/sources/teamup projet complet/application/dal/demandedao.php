<?php
/*
 * teamdao.php
 */
require_once 'config.php';
require_once 'models/demandeentity.php';

class DemandeDAO {
    private $db_connection;
    
    public function __construct() {
        $this->db_connection = get_default_connection();
    }
    
    /**
     * Obtient la liste des demandes
     * @return DemandeEntity[]
     */
    public function getlistdemandes($id_utilisateur=null){
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        // construit la requ�te
        $query = "select demande.*,utilisateur.utilisateur_nom from demande left join utilisateur ".
        "on demande.id_utilisateur = utilisateur.id_utilisateur";
        
        if(isset($id_utilisateur))
            $query.=" where utilisateur.id_utilisateur=$id_utilisateur";
        
        // ex�cute la requ�te
        $result = mysqli_query($cx, $query);
        
        $list = array();
        while( ($row=mysqli_fetch_assoc($result))!=null) {
            $demande = new DemandeEntity();
            $demande->id_demande = $row["id_demande"];
            $demande->demande_objet = $row["demande_objet"];
            $demande->demande_texte = $row["demande_texte"];
            $demande->demande_date_creation = $row["demande_date_creation"];
            $demande->demande_date_echeance = $row["demande_date_echeance"];
            $demande->id_type_demande = $row["id_type_demande"];
            $demande->id_utilisateur = $row["id_utilisateur"];
            $demande->utilisateur_nom = $row["utilisateur_nom"];
            
            $datee = DateTime::createFromFormat('Y-m-d H:i:s', $demande->demande_date_echeance);
            $echeance = $datee->format('d/m/Y');
            $demande->demande_date_echeance= $echeance;
            
            $datec= DateTime::createFromFormat('Y-m-d H:i:s', $demande->demande_date_creation);
            $creation = $datec->format('d/m/Y');
            $demande->demande_date_creation = $creation;
            
            $list[] = $demande;
        }
        
        // lib�re la ressource SQL
        mysqli_free_result($result);
        mysqli_close($cx);
        
        return $list;
    }
    
    
    /**
     * Ajoute une demande
     * @param DemandeEntity $demande
     */
    public function adddemande(DemandeEntity $demande) {
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        $datec = DateTime::createFromFormat('d/m/Y', $demande->demande_date_creation);
        $creation = $datec->format('Y-m-d');
        
        $datee = DateTime::createFromFormat('d/m/Y', $demande->demande_date_echeance);
        $echeance = $datee->format('Y-m-d');
        
        $query = "insert into demande(demande_objet,demande_texte,demande_date_creation,demande_date_echeance,id_type_demande,id_utilisateur) ".
            "values (" 
            ."'$demande->demande_objet'," 
            ."'$demande->demande_texte',"
            ."'$creation',"
            ."'$echeance',"
            ."$demande->id_type_demande,"
            ."$demande->id_utilisateur"
        .")";
        
        mysqli_query($cx, $query);
        
        mysqli_close($cx);
    }
    
    /**
     * Met � jour une demande
     * @param DemandeEntity $demande
     */
    public function editdemande(DemandeEntity $demande) {
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        $datee = DateTime::createFromFormat('d/m/Y', $demande->demande_date_echeance);
        $echeance = $datee->format('Y-m-d');
        
        $query = "update demande set "
                ."demande_objet='$demande->demande_objet',"
                ."demande_texte='$demande->demande_texte',"
                ."demande_date_echeance='$echeance',"
                ."id_type_demande=$demande->id_type_demande,"
                ."id_utilisateur=$demande->id_utilisateur"
                ." where id_demande=$demande->id_demande";

        mysqli_query($cx, $query);
        
        mysqli_close($cx);
    }
    
    /**
     * Obtient la liste des demandes
     * @return DemandeEntity[]
     */
    public function getdemandebyid($id_demande){
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        
        // construit la requ�te
        $query = "select * from demande where id_demande=$id_demande";
        
        // ex�cute la requ�te
        $result = mysqli_query($cx, $query);
        
        $list = array();
        while( ($row=mysqli_fetch_assoc($result))!=null) {
            $demande = new DemandeEntity();
            $demande->id_demande = $row["id_demande"];
            $demande->demande_objet = $row["demande_objet"];
            $demande->demande_texte = $row["demande_texte"];
            $demande->demande_date_creation = $row["demande_date_creation"];
            $demande->demande_date_echeance = $row["demande_date_echeance"];
            $demande->id_type_demande = $row["id_type_demande"];
            $demande->id_utilisateur = $row["id_utilisateur"];
            
            $datee = DateTime::createFromFormat('Y-m-d H:i:s', $demande->demande_date_echeance);
            $echeance = $datee->format('d/m/Y');
            $demande->demande_date_echeance= $echeance;
            
            $datec= DateTime::createFromFormat('Y-m-d H:i:s', $demande->demande_date_creation);
            $creation = $datec->format('d/m/Y');
            $demande->demande_date_creation = $creation;
            
            $list[] = $demande;
        }
        
        // lib�re la ressource SQL
        mysqli_free_result($result);
        mysqli_close($cx);
        
        return $list[0];
    }
}
?>