<?php
/*
 * typedemandedao.php
 */
require_once 'config.php';
require_once 'models/typedemandeentity.php';

class TypeDemandeDAO {
    private $db_connection;
    
    public function __construct() {
        $this->db_connection = get_default_connection();
    }
    
    /**
     * Obtient la liste des types de demandes
     * @return typeDemandeEntity[]
     */
    public function gettypedemandelist(){
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        // construit la requ�te
        $query = "select * from type_demande";
        
        // ex�cute la requ�te
        $result = mysqli_query($cx, $query);
        
        $list = array();
        while( ($row=mysqli_fetch_assoc($result))!=null) {
            $type_demande = new typeDemandeEntity();
            $type_demande->id_type_demande = $row["id_type_demande"];
            $type_demande->type_demande_label = $row["type_demande_label"];
            $list[] = $type_demande;
        }
        
        // lib�re la ressource SQL
        mysqli_free_result($result);
        mysqli_close($cx);
        
        return $list;
    }
}
?>