<?php
/*
 * teamdao.php
 */
require_once 'config.php';
require_once 'models/teamentity.php';

class TeamDAO {
    private $db_connection;
    
    public function __construct() {
        $this->db_connection = get_default_connection();
    }
    
    /**
     * Obtient la liste des �quipes
     * @return TeamEntity[]
     */
    public function getteamlist(){
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        
        // construit la requ�te
        $query = "select * from equipe";
        
        // ex�cute la requ�te
        $result = mysqli_query($cx, $query);
        
        $list = array();
        while( ($row=mysqli_fetch_assoc($result))!=null) {
            $team = new TeamEntity();
            $team->id_equipe = $row["id_equipe"];
            $team->equipe_nom = $row["equipe_nom"];
            $list[] = $team;
        }
        
        // lib�re la ressource SQL
        mysqli_free_result($result);
        mysqli_close($cx);
        
        return $list;
    }
    
    
    /**
     * Ajoute une �quipe
     * @param TeamEntity $team
     */
    public function addteam(TeamEntity $team) {
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        $equipe_nom = $team->equipe_nom;
                
        $query = "insert into equipe(equipe_nom) ".
            "values ('$equipe_nom')";
        
        mysqli_query($cx, $query);
        
        mysqli_close($cx);
    }
    
    /**
     * Met � jour une �quipe
     * @param TeamEntity $team
     */
    public function editteam(TeamEntity $team) {
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        $equipe_nom = $team->equipe_nom;
        $id_equipe = $team->id_equipe;
        
        $query = "update equipe set equipe_nom = '$equipe_nom' where id_equipe=$id_equipe";
        
        mysqli_query($cx, $query);
        
        mysqli_close($cx);
    }
    
    /**
     * Obtient la liste des utilisateurs dans une �quipe
     * @param int $id_equipe
     * @return UserEntity[]
     */
    public function getuserteam($id_equipe) {
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        
        // construit la requ�te
        $query = "select U.* from utilisateur_equipe UE inner join utilisateur U on UE.id_utilisateur=U.id_utilisateur ".
        "where UE.id_equipe=$id_equipe";
        
        // ex�cute la requ�te
        $result = mysqli_query($cx, $query);
        
        $list = array();
        while( ($row=mysqli_fetch_assoc($result))!=null) {
            $user = new UserEntity();
            $user->id_utilisateur = $row["id_utilisateur"];
            $user->utilisateur_creation = $row["utilisateur_creation"];
            $user->utilisateur_email = $row["utilisateur_email"];
            $user->utilisateur_login = $row["utilisateur_login"];
            $user->utilisateur_nom = $row["utilisateur_nom"];;
            $user->utilisateur_pwd = $row["utilisateur_pwd"];
            $list[] = $user;
        }
        
        // lib�re la ressource SQL
        mysqli_free_result($result);
        mysqli_close($cx);
        
        return $list;
    }
    
    /**
     * Ajoute un utilisateur � une �quipe
     * @param int $id_utilisateur
     * @param int $id_equipe
     */
    public function adduserteam($id_utilisateur,$id_equipe) {
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        $query = "insert into utilisateur_equipe(id_utilisateur,id_equipe) values($id_utilisateur,$id_equipe)";        
        mysqli_query($cx, $query);
        
        mysqli_close($cx);
    }
    
    /**
     * Retire un utilisateur d'une �quipe
     * @param int $id_utilisateur
     * @param int $id_equipe
     */
    public function removeuserteam($id_utilisateur,$id_equipe) {
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        $query = "delete from utilisateur_equipe where id_utilisateur=$id_utilisateur and id_equipe=$id_equipe";
        mysqli_query($cx, $query);
        
        mysqli_close($cx);
    }
    
    /**
     * Obtient la liste des utilisateur n'�tant pas dans une �quipe
     * @param int $id_equipe
     * @return UserEntity[]
     */
    public function getusernotinteam($id_equipe) {
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        
        // construit la requ�te
        $query = "select U.* from utilisateur U ".
            "where U.id_utilisateur not in (select id_utilisateur from utilisateur_equipe UE where UE.id_equipe=$id_equipe )";
        
        // ex�cute la requ�te
        $result = mysqli_query($cx, $query);
        
        $list = array();
        while( ($row=mysqli_fetch_assoc($result))!=null) {
            $user = new UserEntity();
            $user->id_utilisateur = $row["id_utilisateur"];
            $user->utilisateur_creation = $row["utilisateur_creation"];
            $user->utilisateur_email = $row["utilisateur_email"];
            $user->utilisateur_login = $row["utilisateur_login"];
            $user->utilisateur_nom = $row["utilisateur_nom"];;
            $user->utilisateur_pwd = $row["utilisateur_pwd"];
            $list[] = $user;
        }
        
        // lib�re la ressource SQL
        mysqli_free_result($result);
        mysqli_close($cx);
        
        return $list;
    }
}
?>