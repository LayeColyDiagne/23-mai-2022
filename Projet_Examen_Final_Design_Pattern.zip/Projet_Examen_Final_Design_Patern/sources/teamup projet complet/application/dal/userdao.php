<?php
/*
 * userdao.php 
 * @author BAG
 * 2019
 */
require_once 'config.php';
require_once 'models/userentity.php';

class UserDAO {
    private $db_connection;
    
    public function __construct() {
        $this->db_connection = get_default_connection();
    }
    
    public function adduser(UserEntity $user) {
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        $login = $user->utilisateur_login;
        $pwd = $user->utilisateur_pwd;
        $nom = $user->utilisateur_nom;
        $email = $user->utilisateur_email;
       
        $datec = DateTime::createFromFormat('d/m/Y', $user->utilisateur_creation);
        $creation = $datec->format('Y-m-d');
        
        $query = "insert into utilisateur(utilisateur_creation,utilisateur_email,utilisateur_login,utilisateur_nom,utilisateur_pwd) ".
            "values ('$creation','$email','$login','$nom','$pwd')";
        
        mysqli_query($cx, $query);
        
        mysqli_close($cx);
    }
    
    public function getuserlist($filtrenom=null) {
        $cx = mysqli_connect($this->db_connection["cx_server"],
            $this->db_connection["cx_login"],
            $this->db_connection["cx_pwd"],
            $this->db_connection["cx_dbname"]);
        
        
        // construit la requ�te
        $query = "select * from utilisateur";
        if(isset($filtrenom) && $filtrenom!=null && $filtrenom!='') {
            // supprime les signes dangereux
            $like = str_replace(';','', $filtrenom);
            $like = str_replace('\'','', $filtrenom);
            
            $query.=" where utilisateur_nom like '%$like%'";
        }
        
        // ex�cute la requ�te
        $result = mysqli_query($cx, $query);
        
        $list = array();
        while( ($row=mysqli_fetch_assoc($result))!=null) {
            $user = new UserEntity();
            $user->id_utilisateur = $row["id_utilisateur"];
            $user->utilisateur_creation = $row["utilisateur_creation"];
            $user->utilisateur_email = $row["utilisateur_email"];
            $user->utilisateur_login = $row["utilisateur_login"];
            $user->utilisateur_nom = $row["utilisateur_nom"];;
            $user->utilisateur_pwd = $row["utilisateur_pwd"];
            $list[] = $user;
        }
        
        // lib�re la ressource SQL
        mysqli_free_result($result);
        
        mysqli_close($cx);
        return $list;
    }
}
?>