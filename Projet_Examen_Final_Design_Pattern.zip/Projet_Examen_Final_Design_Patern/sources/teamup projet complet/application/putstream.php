<?php
/*
 * getstream.php
 */
$content_name = $_REQUEST["content"];
require_once '../vendor/autoload.php';
require_once 'service/messageservice.php';

    $filepath = __DIR__ . "/multimedia/" . $content_name;
    $content_type="video/mp4";
    $content_data = file_get_contents($filepath);
    $content_length = filesize($filepath);
    $content_date = date("D, d M Y H:i:s",filemtime($filepath));
    
    $mservice = new MessageService();
    $mservice->putBlob($content_name, $content_type, $content_date, $content_data, $content_length);
?>