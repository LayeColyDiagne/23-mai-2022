<?php
/*
 * getstream.php
 */
    $content_name = $_REQUEST["content"];
    $content_source = $_REQUEST["source"];
    
    require_once 'service/LobStream.php';
    require_once '../vendor/autoload.php';
    require_once 'service/messageservice.php';
    
    $lobs = new LobStream();
    if($content_source==="file")
    {
        $filepath = __DIR__ . "/multimedia/" . $content_name;
        $lobs->set_file($filepath);
        
        $lobs->content_type="video/mp4";
    }
    if($content_source==="blob")
    {
        $mservice = new MessageService();
        $content = $mservice->getBlob($content_name);
        $lobs->set_blob($content['content_data']);
    }
    
    $lobs->start();
?>