<?php 
/*
 * datecontrol.php
 */
require_once '../comfpl/views/viewComp.php';

class datePicker extends viewComp
{
    public $width;
    public $value;
    
    public function __construct() {
        $this->width = 300;
    }
    
    public function renderBody(){
        echo "<input id='$this->id' width='$this->width' value='$this->value' />";
    }
}
?>