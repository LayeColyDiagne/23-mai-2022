<?php //{layout:../_mainLayout.php}?><?php $model=FPLGLobal::$view_result->model; ?>
<div class="container">
	<div class="row">
		<div class="col-lg-12"><h5>Recherche de <?php echo $model->query?></h5></div>
	</div>
	
	<div class="row">
		<div class="col-lg-12">
			<?php 
                foreach($model->results as $row)
                {
                    ?>
                    <div><?php echo $row["message"]?>
                    <br/>
                    <i><?php echo $row["from"]." ".$row["attendee"]?></i>&nbsp;
                    <?php echo $row["date"] ?>
                    </div>
                    <br>
                    <?php 
                }
            ?>		
		</div>
	</div>
</div>

