<?php require_once '../comfpl/main.php';?><html>
<head>
<title><?php echo (isset(\FPLGlobal::$view_bag->title)?\FPLGlobal::$view_bag->title:'Team up')?></title>
<?php require_once 'phpinclude/commonmeta.php';?>
<?php require_once 'phpinclude/theme.php';?>
<?php FPLGlobal::render_bundle_css()?> 
<?php FPLGlobal::render_bundle_script()?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-149689530-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-149689530-1');
</script>


<script charset='UTF-8'>
window['adrum-start-time'] = new Date().getTime();
(function(config){
    config.appKey = 'AD-AAB-AAT-CDS';
    config.adrumExtUrlHttp = 'http://cdn.appdynamics.com';
    config.adrumExtUrlHttps = 'https://cdn.appdynamics.com';
    config.beaconUrlHttp = 'http://pdx-col.eum-appdynamics.com';
    config.beaconUrlHttps = 'https://pdx-col.eum-appdynamics.com';
    config.xd = {enable : true};
})(window['adrum-config'] || (window['adrum-config'] = {}));
</script>
<script src='//cdn.appdynamics.com/adrum/adrum-4.5.13.2640.js'></script>

</head>
<body>
	<?php require_once 'phpinclude/navbar.php';?>
	<?php FPLGlobal::render_view(); ?>
</body>
</html>