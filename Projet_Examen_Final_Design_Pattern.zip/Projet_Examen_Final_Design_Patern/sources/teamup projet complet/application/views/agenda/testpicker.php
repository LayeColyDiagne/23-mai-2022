<?php //{layout:../_mainLayout.php}?><?php $model=FPLGLobal::$view_result->model; ?>
<?php 
require_once 'controls/datepicker.php';
    
    $g = viewComp::instanciate("datePicker","p1");
    $g->width = 250;
    $g->configureJavaScript( function() { ?>
    <script>
    $(document).ready(function() {
        $('#<?php echo $this->id ?>').datepicker({
        	uiLibrary: 'bootstrap4',
        	locale: 'fr-fr',
            format: 'dd mmm yyyy'
	 });
    });
    </script>
<?php } ) ?>

<?php $g->render() ?>
