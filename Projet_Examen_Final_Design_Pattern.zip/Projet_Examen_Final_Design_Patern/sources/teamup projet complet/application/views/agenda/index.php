<?php //{layout:../_mainLayout.php}?><?php $model=FPLGLobal::$view_result->model; ?>
<?php 
require_once 'controls/datepicker.php';
    
$dtstart = viewComp::instanciate("datePicker","dtstart");
$dtstart->width = 180;
$dtstart->value = $model->dtstart;
$dtstart->configureJavaScript( function() { ?>
<script>
$(document).ready(function() {
    $('#<?php echo $this->id ?>').datepicker({
    	uiLibrary: 'bootstrap4',
    	locale: 'fr-fr',
        format: 'dd/mm/yyyy'
 });
});
</script>
<?php } );
    
    $dtend = viewComp::instanciate("datePicker","dtend");
    $dtend->width = 180;
    $dtend->value = $model->dtend;
    $dtend->configureJavaScript( function() { ?>
<script>
$(document).ready(function() {
    $('#<?php echo $this->id ?>').datepicker({
    	uiLibrary: 'bootstrap4',
    	locale: 'fr-fr',
        format: 'dd/mm/yyyy'
 });
});
</script>
<?php } );
    
    ?>
    
    <script>
    var grid;
    
    $(document).ready(function () {
       grid = $('#grid').grid({
       primaryKey: 'id_evenement',
       locale: 'fr-fr',
       dataSource: '<?php html::action_href("agenda" , "agenda", "listevdata")?>',
       uiLibrary: 'bootstrap4',
       columns: [
       { field: 'id_evenement', width: 50, title:'ID' },
       { field: 'id_utilisateur',title:'Organisateur' },
       { field: 'evenement_dtstart',title:'Debut' },
       { field: 'evenement_dtend',title:'Fin' },
       { field: 'evenement_subject',title:'Objet' },
       { field: 'id_evenement', title:'Edit', renderer: 
    	   function (value, record) { 
    	      	return "<a href='<?php html::action_href('agenda', 'agenda', 'agendaedit')?>-id-" + value + "'>Edit</a>"; 
    	   }  
    	} 
    	   
       ]
       ,
       pager: { limit: 5, sizes: [2, 5, 10, 20] }
       });
    
        // chargement de la liste des utilisateurs
        var lsUrl = '<?php html::action_href("users" , "user", "getuserlist")?>';
        
        $.get(lsUrl, function (opdata) {
           $.each(opdata.records, function (key, value) {
               $('#id_utilisateur').append('<option value=' + value.id_utilisateur + '>' + value.utilisateur_nom + '</option>');
           });
        });
       
        $('#btnFiltre').on('click', function () {
        	grid.reload(
        	    	{ 
            	    	id_utilisateur: $('#id_utilisateur').val(), 
                    	dtstart: $('#dtstart').val(), 
                    	dtend: $('#dtend').val() 
                	});
        });
    });
    	
    </script> 
   
<form class="form-inline">
<div class="container">
	<div class="row">
		<div class="col"><h4>Agenda</h4></div>
		<div class="col"><?php html::action_link('agenda', 'agenda', 'agendaadd', 'Nouveau rendez-vous')?></div>	
	</div>
	<div class="row">
		<div class="col">
            <table>
            	<tr>
            		<td>
            			<select name="id_utilisateur" id="id_utilisateur">
            				<option value="null">Tous</option>
            			</select></td>
            		<td>Entre</td>
            		<td><?php $dtstart->render() ?></td>
            		<td>Et</td>
            		<td><?php $dtend->render() ?></td>
            		<td><input type="button" value="Actualiser" id="btnFiltre" name="btnFiltre"></td>
            	</tr>
            </table>
		</div>
		<div class="row">
    		<div class="col">
    			<table id="grid"></table>
    		</div>
		</div>		
	</div>
	</div>
</div>
</form>