<?php //{layout:../_mainLayout.php}?><?php $model=FPLGLobal::$view_result->model; ?>

<?php html::begin_form('agenda','agenda','agendaedit','post',array("id"=>$model->evenement->id_evenement)) ?>
<div class="container">
	<div class="row">
		<div class="col"><h4>Modifier rendez-vous</h4></div>
	</div>
	<div class="row">
		<div class="col">
    		<div class="form-group">
    			<div class="row">
    				<div class="col">
	        			<?php html::label_for(null,function($model) { return "Organisateur:"; },null,"id_utilisateur")?>
        			</div>
				</div>
    			<div class="row">
    				<div class="col">
			    		<?php html::list_for($model, function ($model) { return $model->participants_items; }, "id_utilisateur", $model->evenement->id_utilisateur)?>
        			</div>
				</div>
        	</div>
        	<div class="form-group">
    			<div class="row">
    				<div class="col">
		        		<?php html::label_for(null,function($model) { return "Participants:"; },null,"participants_selected")?>
        			</div>
				</div>
    			<div class="row">
    				<div class="col">
		        		<?php html::list_for($model, function ($model) { return $model->participants_items; }, 
                        "participants_selected[]", 
		        		$model->participants_selected,
		        		array("size"=>4,"multiple"=>""))?>
        			</div>
				</div>
        	</div>
        	<div class="form-group">
    			<div class="row">
    				<div class="col">
		        		<?php html::label_for(null,function($model) { return "D&eacute;but:"; },null,"evenement_dtstart")?>
        			</div>
				</div>
        		<div class="row">
    				<div class="col">
						<input id="evenement_dtstart" name="evenement_dtstart" width="220" value="<?php echo $model->evenement->evenement_dtstart ?>" />
                         <script>
                             $('#evenement_dtstart').datetimepicker({ uiLibrary: 'bootstrap4',
                                locale: 'fr-fr',
                                format: 'dd/mm/yyyy HH:MM' });
                         </script>
					</div>
				</div>
        	</div>
    		<div class="form-group">
        		<div class="row">
    				<div class="col">
		        		<?php html::label_for(null,function($model) { return "Fin:"; },null,"evenement_dtend")?>
					</div>
				</div>
        		<div class="row">
    				<div class="col">        
		        		<input id="evenement_dtend" name="evenement_dtend" width="220"  value="<?php echo $model->evenement->evenement_dtend ?>"/>
                         <script>
                             $('#evenement_dtend').datetimepicker({ uiLibrary: 'bootstrap4',
                                locale: 'fr-fr',
                                format: 'dd/mm/yyyy HH:MM' });
                         </script>
					</div>
				</div>
        	</div>
    	</div>
    	<div class="col">
        	<div class="form-group">
        		<div class="row">
    				<div class="col">        
		        		<?php html::label_for(null,function($model) { return "Emplacement:"; },null,"evenement_location")?>
					</div>
				</div>
        		<div class="row">
    				<div class="col">        
		        		<?php html::edit_for($model, function ($model) { return $model->evenement->evenement_location;}, "evenement_location")?>
					</div>
				</div>
        	</div>
        	<div class="form-group">
        		<div class="row">
    				<div class="col">        
		        		<?php html::label_for(null,function($model) { return "Objet:"; },null,"evenement_subject")?>
					</div>
				</div>
        		<div class="row">
    				<div class="col">        
		        		<?php html::edit_for($model, function ($model) { return $model->evenement->evenement_subject;}, "evenement_subject")?>
					</div>
				</div>
        	</div>
        	<div class="form-group">
    			<div class="row">
    				<div class="col">
		        		<?php html::label_for(null,function($model) { return "Description:"; },null,"evenement_description")?>
        			</div>
				</div>
    			<div class="row">
    				<div class="col">
		        		<?php html::textedit_for($model, function ($model) { return $model->evenement->evenement_description;}, "evenement_description", array("rows"=>5,"cols"=>30))?>
        			</div>
				</div>
        	</div>
    	</div>
	</div>
	<div class="row">
		<div class="col">
	    	<?php html::action_button_for($model, function($model) { return "Modifier rendez-vous";}, "btn", "agenda", "agenda", "agendaedit",array("id"=>$model->evenement->id_evenement))?>	
    	</div>
	</div>
	<div class="row">
		<div class="col">
	    	<div><?php html::validation_summary()?></div>	
    	</div>
	</div>
	<div class="row">
		<div class="col">
            <a target="_blank" 
            	href="<?php echo 
            	html::action_href("agenda", "agenda", "sendmeeting",
                                     array("idev" => $model->evenement->id_evenement))?>">Obtenir RDV.ics</a>
    	</div>
	</div>
</div>
<?php html::end_form()?>