<?php //{layout:../_mainLayout.php}?><?php $model=FPLGLobal::$view_result->model; ?>
<script>
//var data='<?php FPLGlobal::render_action("general", "home", "getuserlist")?>';
var grid;

$(document).ready(function () {
   grid = $('#grid').grid({
   primaryKey: 'id_utilisateur',
   dataSource: '<?php html::action_href("general" , "home", "getuserlist")?>',
   uiLibrary: 'bootstrap4',
   columns: [
   { field: 'id_utilisateur', width: 50, title:'ID' },
   { field: 'utilisateur_nom',title:'Nom' },
   { field: 'utilisateur_email',title:'Email' },
   ]
   ,
   pager: { limit: 5, sizes: [2, 5, 10, 20] }
   });
  
});
	
</script>
<div class="container">
	<div class="row">
		<div class="col">
			<table id="grid"></table>
		</div>
	</div>
</div>
