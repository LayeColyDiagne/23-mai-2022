<?php //{layout:../_mainLayout.php}?><?php $model=FPLGLobal::$view_result->model; ?>
<h2>Accueil</h2>
<div><?php echo $model->message?></div>