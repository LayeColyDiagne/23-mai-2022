<?php //{layout:../_mainLayout.php}?><?php $model=FPLGLobal::$view_result->model; ?>
<div class="container">
	<div class="row">
		<div class="col">Test de scripting</div>
	</div>
	<div class="row">
		<div class="col"><?php echo $model->table ?></div>
	</div>
</div>