<?php //{layout:../_mainLayout.php}?><?php $model=FPLGLobal::$view_result->model; ?>
<div class="container">
	<div class="row">
		<div class="col">Test d'injection de d&eacute;pendance</div>
	</div>
	<div class="row">
		<div class="col">GUID <?php echo $model->guid ?></div>
	</div>
	<?php  \TraceListener::write_message("fin de rendu de la vue",TraceLevel::LEVEL_VERBOSE);
	?>
</div>