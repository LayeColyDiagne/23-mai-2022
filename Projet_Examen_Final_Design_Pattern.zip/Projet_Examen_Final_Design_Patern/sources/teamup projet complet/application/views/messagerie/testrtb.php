<?php //{layout:../_mainLayout.php}?><?php $model=FPLGLobal::$view_result->model; ?>
<!--  
<link rel="stylesheet" href="summernote/summernote-lite.css">
<script type="text/javascript" src="summernote/summernote.js"></script>
<script type="text/javascript" src="summernote/lang/summernote-fr-FR.js"></script>
-->
  <script type="text/javascript">
    $(document).ready(function() {
      $('#richcontent').summernote({
        height: 300,
        tabsize: 2,
        lang: 'fr-FR'
      });
    });
  </script>
  
  <div id="richcontent"></div>