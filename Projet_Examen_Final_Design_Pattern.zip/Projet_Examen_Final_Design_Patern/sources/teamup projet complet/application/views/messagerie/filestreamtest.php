<?php //{layout:../_mainLayout.php}?><?php $model=FPLGLobal::$view_result->model; ?>
<video controls preload="auto" src="getstream.php?source=blob&content=apollo.mp4"></video>