<?php //{layout:../_mainLayout.php}?><?php $model=FPLGLobal::$view_result->model; ?>

<script>
var displayname='<?php echo FPLGlobal::get_user_identity()->display_name ?>';
var socket;

var username;
var userstatus;

$(document).ready(function() {
  $('#message').summernote({
    height: 300,
    tabsize: 2,
    lang: 'fr-FR'
  });
});

$(document).ready( function() {
socket.emit('has-messages', displayname);

// v�rifie � l'affichage de la page s'il y a des messages en attente
socket.on('has-messages', function(data) {
    if(data)
    	socket.emit('get-pending-messages', displayname);        
});

// r�ception des messages en attente
socket.on('get-pending-messages', function(data) {
    addmessage("en attente", data, 4);

    // met � jour l'indicateur de messages
    socket.emit('has-messages', displayname);
});
    
socket.on('send-message', function(data) {
    addmessage(data.displayname, data.message, 2);
});

socket.on('join-chat', function(displayname) {
    $('#messagethread').prepend('<div><em>' + displayname + ' est connect&eacute;</em></div><br>');
});

socket.on('private-message', function(data) {
	addmessage("[Priv&eacute;] " + data.displayname, data.message, 3);
});

$('#btnSend').on('click',function () {
	var isAll = $('#chkAll').prop('checked');
	
    if(isAll == true) {
    	// g�n�ral
        var message = $('#message').val();
        socket.emit('send-message', message); 
        addmessage(displayname, message, 1); 
    
        var sendurl = '<?php html::action_href("messagerie" , "chat", "recordmessage")?>'+
        "?attendee=" + encodeURI("Tous") + "&message=" + encodeURIComponent(message);

        alert(sendurl);
        
        $.get(sendurl, function (opdata) {  
            alert(sendurl + " " + opdata); 
        });
    
        $('#message').val('').focus(); 
    } else {
    	// priv�
    	var message = $('#message').val();
    	var attendee = $('#id_utilisateur').val();
    		
    	if(userstatus=='online' || userstatus=='donotdisturb') {
            socket.emit('private-message', attendee, message); 
            addmessage("[Priv&eacute;] " + displayname + " &gt; " + attendee, message, 1);
    
            var sendurl = '<?php html::action_href("messagerie" , "chat", "recordmessage")?>'+
    		"?attendee=" + encodeURI(attendee) + "&message=" + encodeURIComponent(message);

            $.get(sendurl, function (opdata) {   
                alert(sendurl +" "+opdata);
    	    });
    	    
    	} else {
    		var sendurl = '<?php html::action_href("messagerie" , "chat", "sendoffline")?>'+
    			"?attendee=" + encodeURI(attendee) + "&message=" + encodeURIComponent(message);
    		
    		$.get(sendurl, function (opdata) {
    			$('#messagethread').prepend('<div>' + opdata + '</div>');
    	    });
    	} 
        $('#message').val('').focus(); 
    }
});

 	// chargement de la liste des utilisateurs
    var lsUrl = '<?php html::action_href("users" , "user", "getuserlist")?>';
    
    $.get(lsUrl, function (opdata) {
        $.each(opdata.records, function (key, value) {
            $('#id_utilisateur').append('<option value=' + value.utilisateur_nom + '>' + value.utilisateur_nom + '</option>');
        });
     });

    socket.on('get-status', function(status) {
        $('#userstatus').text(status);
        userstatus = status;
    });
});

function showstatus() {
	username = $('#id_utilisateur').val();
	socket.emit('get-status', username);
}

function decodeHtml(value) {
	return $("<div/>").html(value).text();
}

function addmessage(displayname, message, sender) {
	message = decodeHtml(message);
	switch(sender) {
    	case 1: 
            $('#messagethread').
            	prepend("<div style='background-color: lightgrey; float:left;'><strong>" + displayname + '</strong> ' + message + '</div><br>');
    		break;
    	case 2: 
    		$('#messagethread').
    			prepend("<div style='background-color: #A0FFA0; float:right'><strong>" + displayname + '</strong> ' + message + '</div><br>');
    		break;
    	case 3: 
    		$('#messagethread').
    		prepend("<div style='background-color: #BCF7FF; float:right'><strong>" + displayname + '</strong> ' + message + '</div><br>');
    		break;
    	case 3: 
    		$('#messagethread').
    		prepend("<div style='background-color: yellow; float:right'><strong>" + displayname + '</strong> ' + message + '</div><br>');
    		break;
    	default: 
    		$('#messagethread').
    		prepend("<div style='background-color: lightgrey; float:right'><strong>" + displayname + '</strong> ' + message + '</div><br>');
    		break;
	}        
}

</script>
<div class="container">
	<form id="formulaire_chat">

    	<div class="row">
    		<div class="col"><h4>Messagerie instantan&eacute;e</h4></div>
    	</div>
    	<div class="row">
    		<div class="col"><div id="messagethread"></div></div>
    	</div>
		<div class="row">
    		<div class="col-9">
                <textarea name="message" id="message" class="form-control" 
                	placeholder="Votre message..." autofocus rows="5" cols="40"></textarea>
        	</div>
        	<div class="col-3">
                <input type="button" id="btnSend" name="btnSend" value="Envoyer" class="form-control" />
    		</div>
    	</div>
        <div class="row">
        	<div class="col">
                <div class="form-check">
                  <input type="radio" id="chkAll" name="chkAll" value="all" class="form-check-input" checked>
                  <label class="form-check-label" for="chkAll">
                    Discussion g&eacute;n&eacute;rale
                  </label>
                </div>
                <div class="form-check">
                  <input type="radio" id="chkPrivate" name="chkAll" value="private" class="form-check-input">  
                  <label class="form-check-label" for="chkPrivate">
                    Discussion priv&eacute;e
                  </label>
                  <div>
                  	<select name="id_utilisateur" id="id_utilisateur" onchange='showstatus()')>
        			</select>
                  </div>
                  <span id='userstatus'></span>
                </div>
        	</div>
        </div>
    </form>
</div>