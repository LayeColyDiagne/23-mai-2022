<?php //{layout:../_mainLayout.php}?><?php $model=FPLGLobal::$view_result->model; ?>
<?php html::begin_form('demandes','demande','editdemande','post',array("id"=>$model->id)) ?>
<div class="container">
	<div class="row">
		<div class="col"><h4>Modifier une demande</h4></div>
	</div>
	<div class="row">
		<div class="col">
    		<div class="form-group">
    			<div class="row">
    				<div class="col">
	        			<?php html::label_for(null,function($model) { return "Objet:"; },null,"demande_objet")?>
        			</div>
				</div>
    			<div class="row">
    				<div class="col">
			    		<?php html::edit_for($model, function ($model) { return $model->demande->demande_objet;}, "demande_objet")?>
        			</div>
				</div>
        	</div>
        	<div class="form-group">
    			<div class="row">
    				<div class="col">
		        		<?php html::label_for(null,function($model) { return "Demande:"; },null,"demande_texte")?>
        			</div>
				</div>
    			<div class="row">
    				<div class="col">
		        		<?php html::textedit_for($model, function ($model) { return $model->demande->demande_texte;}, "demande_texte", array("rows"=>5,"cols"=>30))?>
        			</div>
				</div>
        	</div>
    	</div>
    	<div class="col">
        	<div class="form-group">
    			<div class="row">
    				<div class="col">
		        		<?php html::label_for(null,function($model) { return "Date de la demande:"; },null,"demande_date_creation")?>
        			</div>
				</div>
        		<div class="row">
    				<div class="col">
						<?php html::edit_for($model, function ($model) { return $model->demande->demande_date_creation;}, "demande_date_creation")?>
					</div>
				</div>
        	</div>
    		<div class="form-group">
        		<div class="row">
    				<div class="col">
		        		<?php html::label_for(null,function($model) { return "Ech&eacute;ance:"; },null,"demande_date_echeance")?>
					</div>
				</div>
        		<div class="row">
    				<div class="col">        
		        		<?php html::edit_for($model, function ($model) { return $model->demande->demande_date_echeance;}, "demande_date_echeance")?>
					</div>
				</div>
        	</div>
        	<div class="form-group">
        		<div class="row">
    				<div class="col">        
		        		<?php html::label_for(null,function($model) { return "Type de demande:"; },null,"id_type_demande")?>
					</div>
				</div>
        		<div class="row">
    				<div class="col">        
		        		<?php html::list_for($model, function ($model) { return $model->typeDemandelist; }, "id_type_demande", $model->demande->id_type_demande,array("size"=>4))?>
					</div>
				</div>
        	</div>
            <div class="form-group">
            	<div class="row">
            		<div class="col">        
                		<?php html::label_for(null,function($model) { return "Affect&eacute &agrave;:"; },null,"id_utilisateur")?>
            		</div>
            	</div>
            	<div class="row">
            		<div class="col">
            			<?php html::list_for($model, function ($model) { return $model->utilisateurlist; }, "id_utilisateur", $model->demande->id_utilisateur,array("size"=>4))?>    					
            		</div>
            	</div>
            </div>
		</div>
	</div> 
        	
    	</div>
	</div>
<div class="row">
	<div class="col">
    	<?php html::action_button_for($model, function($model) { return "Modifier la demande";}, "btn", "demandes", "demande", "editdemande",array("id"=>$model->id))?>	
	</div>
</div>
	<div class="row">
		<div class="col">
	    	<div><?php html::validation_summary()?></div>	
    	</div>
	</div>
</div>
<?php html::end_form()?>