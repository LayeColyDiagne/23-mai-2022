<?php //{layout:../_mainLayout.php}?><?php $model=FPLGLobal::$view_result->model; ?>
<div class="container">
	<div class="row">
		<div class="col"><h4>Liste des demandes</h4></div>
		<div class="col"><?php html::action_link('demandes', 'demande', 'adddemande', 'Nouvelle demande')?></div>	
	</div>
</div>

