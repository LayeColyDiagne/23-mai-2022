<?php //{layout:../_mainLayout.php}?><?php $model=FPLGLobal::$view_result->model; ?>
<script>
var grid;

$(document).ready(function () {
   grid = $('#grid').grid({
   primaryKey: 'id_utilisateur',
   locale: 'fr-fr',
   dataSource: '<?php html::action_href("demandes" , "demande", "listdemandedata")?>',
   uiLibrary: 'bootstrap4',
   columns: [
   { field: 'id_demande', width: 50, title:'ID' },
   { field: 'demande_date_creation',title:'Date demande' },
   { field: 'demande_objet',title:'Objet' },
   { field: 'utilisateur_nom',title:'Utilisateur' },
   { field: 'id_demande', title:'Edit', renderer: 
	   function (value, record) { 
	      	return "<a href='<?php html::action_href('demandes', 'demande', 'editdemande')?>-id-" + value + "'>Edit</a>"; 
	   }  
	} 
	   
   ]
   ,
   pager: { limit: 5, sizes: [2, 5, 10, 20] }
   });

   // chargement de la liste des utilisateurs
   var lsUrl = '<?php html::action_href("users" , "user", "getuserlist")?>';

   $.get(lsUrl, function (opdata) {
       $.each(opdata.records, function (key, value) {
           $('#lstName').append('<option value=' + value.id_utilisateur + '>' + value.utilisateur_nom + '</option>');
       });
   });
   
    $('#btnFiltre').on('click', function () {
       if($('#btnFiltre').text()=='Filtrer') {
    	    grid.reload({ name: $('#lstName').val() });
    	    $('#btnFiltre').text('Annuler');
       } else {
    	    grid.reload( { name: 'null' });
    	    $('#btnFiltre').text('Filtrer');
       }
    });
});
	
</script>
<form class="form-inline">
<div class="container">
    <div class="row">
    	<div class="col"><h4>Liste des demandes</h4></div>
    	<div class="col"><?php html::action_link('demandes', 'demande', 'adddemande', 'Nouvelle demande')?></div>	
    </div>
  	<div class="row">
		<div class="col">
			<select class="form-control" name='lstName' id='lstName'>
			
			</select>
    		<button class="btn btn-outline-success" type="button" name='btnFiltre' id='btnFiltre'>Filtrer</button>
		</div>
	</div> 
	<div class="row">
		<div class="col">
			<table id="grid"></table>
		</div>
		
	</div>
</div>
</form>