<?php require_once 'config.php'; ?><?php require_once '../comfpl/main.php';?><?php 
/*
 * adduser.php
 */
require_once 'models/userentity.php';
require_once 'service/userservice.php';

if($_SERVER['REQUEST_METHOD']==='POST') {
    $login = $_POST["utilisateur_login"];
    $pwd = $_POST["utilisateur_pwd"];
    $nom = $_POST["utilisateur_nom"];
    $email = $_POST["utilisateur_email"];
    $creation= date("d/m/Y");
    
    $user = new UserEntity();
    $user->utilisateur_creation = $creation;
    $user->utilisateur_email = $email;
    $user->utilisateur_login = $login;
    $user->utilisateur_nom = $nom;
    $user->utilisateur_pwd = $pwd;
    
    $service = new UserService();
    $service->adduser($user);
}


?><html>
<head>
<title>Team up - Ajout utilisateur</title>
<?php require_once 'phpinclude/commonmeta.php';?>
<?php require_once 'phpinclude/theme.php';?>
<?php FPLGlobal::render_bundle_css()?> 
<?php FPLGlobal::render_bundle_script()?>
</head>
<body>
	<?php require_once 'phpinclude/navbar.php';?>
	
	<form action="adduser.php" method="post">
	<input type="hidden" id="id_utilisateur">
	<div class="container-fluid">
		<div>Ajout d'un utilisateur</div>
		<div class="row">
			<div class="col">
			<table>
				<tr>
					<td>Nom:</td>
					<td><input type="text" name="utilisateur_nom" id="utilisateur_nom"></td>
				</tr>
				<tr>
					<td>Identifiant:</td>
					<td><input type="text" name="utilisateur_login" id="utilisateur_login"></td>
				</tr>
				<tr>
					<td>Mot de passe:</td>
					<td><input type="password" name="utilisateur_pwd" id="utilisateur_pwd"></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><input type="text" name="utilisateur_email" id="utilisateur_email"></td>
				</tr>
			</table>
			</div>
		</div>
		<div class="row">
			<div class="col"><input type="submit" value="Ajouter" id="cmd_adduser"></div>
		</div>
	</div>
	</form>
</body>
</html>