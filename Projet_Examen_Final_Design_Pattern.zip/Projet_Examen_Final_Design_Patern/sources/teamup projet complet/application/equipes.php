<?php require_once 'config.php'; ?><?php require_once '../comfpl/main.php';?>
<?php 
/*
 * equipes.php
 */

require_once 'service/teamservice.php';
require_once 'models/userentity.php';

$teamservice = new TeamService();
$lst_userinteam="";
$lst_usernotinteam="";
$id_equipe="";

function update_team($id_equipe) {
    global $lst_userinteam;
    global $lst_usernotinteam;
    global $teamservice;
    
    $userinteam = $teamservice->getuserteam($id_equipe);
    $usernotinteam = $teamservice->getusernotinteam($id_equipe);
        
    $lst_userinteam = "";
    foreach($userinteam as $t) {
        $lst_userinteam.="<option value='$t->id_utilisateur'>$t->utilisateur_nom</option>";
    }
    
    $lst_usernotinteam = "";
    foreach($usernotinteam as $t) {
        $lst_usernotinteam.="<option value='$t->id_utilisateur'>$t->utilisateur_nom</option>";
    }
}

if($_SERVER['REQUEST_METHOD']==='POST') {
    global $id_equipe;
    
    if(isset($_POST['cmd_addteam'])) {
        $team=new TeamEntity();
        $team->equipe_nom=$_POST['equipe_nom'];
        $teamservice->addteam($team);
    }
    
    if(isset($_POST['lst_equipe'])) {
        $id_equipe=(int) $_POST['lst_equipe'];
        update_team($id_equipe);
    }
    
    if(isset($_POST['cmd_adduserinteam'])) {
        $id_equipe=(int) $_POST['lst_equipe'];
        $id_utilisateur = (int) $_POST['lst_usernotinteam'];
        
        $teamservice->adduserteam($id_utilisateur, $id_equipe);
        update_team($id_equipe);
    }
    
    if(isset($_POST['cmd_removeuserinteam'])) {
        $id_equipe=(int) $_POST['lst_equipe'];
        $id_utilisateur = (int) $_POST['lst_userinteam'];
        
        $teamservice->removeuserteam($id_utilisateur, $id_equipe);
        update_team($id_equipe);
    }
    
}
?>
<html>
<head>
<title>Team up - Equipes</title>
<?php require_once 'phpinclude/commonmeta.php';?>
<?php require_once 'phpinclude/theme.php';?>
<?php FPLGlobal::render_bundle_css()?> 
<?php FPLGlobal::render_bundle_script()?>
</head>
<body>
	<?php require_once 'phpinclude/navbar.php';?>

    <form method="post" class="form-inline" action="equipes.php">
    <div class="container">
    	<div class="row">
    		<div class="col">
    			<div class="row"><input class="form-control" type="text"
    				placeholder="Equipe" aria-label="Nom" name='equipe_nom'>
    				<button class="btn btn-outline-success" type="submit" name="cmd_addteam">Ajouter</button></div>
    			<div class="row">
    				<select name="lst_equipe" class="form-control" size=3 onchange='this.form.submit()'>
    				<?php 
    				    $teams = $teamservice->getteamlist();
    				    foreach ($teams as $team) { ?>
    					<option value='<?php echo $team->id_equipe?>' 
    					   <?php echo $team->id_equipe==$id_equipe?" selected":""?>><?php echo $team->equipe_nom?></option>        
    		        <?php 
    				    }
    				?>
    				</select>
    			</div>
    		</div>
    		
    		<div class="col">
    			<div class="row">
    				<div class="col">
        				<div class="row">
        					<div class="col">
        						Utilisateurs dans l'equipe
        					</div>
        				</div>
        				<div class="row">
    	    				<div class="col">
    		    				<select name="lst_userinteam" size="3" class="form-control"><?php echo $lst_userinteam?></select>
    	    				</div>
    	    				<div class="col">
			    				<button class="btn btn-outline-success" type="submit" name="cmd_removeuserinteam">Retirer utilisateur</button>   	    					
    	    				</div>
        				</div>
    				</div>
    			</div>
    			<div class="row">
    				<div class="col">
        				<div class="row">
        					<div class="col">
        						Utilisateurs hors de l'equipe
        					</div>
        				</div>
        				<div class="row">
    	    				<div class="col">
    		    				<select name="lst_usernotinteam" size="3" class="form-control"><?php echo $lst_usernotinteam?></select>
    	    				</div>
    	    				<div class="col">
			    				<button class="btn btn-outline-success" type="submit" name="cmd_adduserinteam">Ajouter utilisateur</button>   	    					
    	    				</div>
        				</div>
    				</div>
    			</div>
    		</div>
    	</div>
    </div>
    </form>
</body>
</html>
	