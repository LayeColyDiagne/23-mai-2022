<?php
/*
 * homeController.php
 */
namespace teamup\Controllers\general;

use comfpl\controllers\BaseController;
use comfpl\views\JsonResult;

require_once 'models/userentity.php';
require_once 'service/userservice.php';

/**
 * @Autorisation(access_control_mode=Autorisation::DENY_ANONYMOUS)
 */
class homeController extends BaseController
{
    public function index($model)
    {
        $model->message = "Bienvenue";
        return $this->View($model, "index");
    }
    
    /**
     * Obtient la liste pagin�e des utilisateurs
     * @param int $page
     * @param int $limit
     * @return array
     */
    function getusersdata($page=null,$limit=null){
        $userservice = new \UserService();
        $p = $userservice->getuserlist();
        
        $r=array();
        if($page!=null && $limit!=null)
        {
            $start = ($page - 1) * $limit;
        } else {
            $start = 0;
            $limit = count($p);
        }
        for($i = $start; $i < $start + $limit && $i < count($p); $i++)
            $r[] = $p[$i];
            
            return array("records" => $r, "total" => count($p));
    }
    
    /**
     * Action get_livre_data
     * @param \Entity $model
     * @return \comfpl\views\JsonResult
     */
    public function getuserlist($model) {
        $page = isset($model->page) ? $model->page : null;
        $limit = isset($model->limit) ? $model->limit : null;
        
        $p = $this->getusersdata($page,$limit);
        $json_user_list = json_encode($p);
        
        return new JsonResult($json_user_list);
    }    
    
    
    /**
     * @Autorisation(access_control_mode=Autorisation::DENY_LIST_USERS, deny_list='John') 
     * Action listusers
     * @param \Entity $model
     * @return \comfpl\views\ViewResult
     */
    public function listusers($model) {
        return $this->View($model, "listusers");
    }
}
?>