<?php
/*
 * chatController.php
 */
namespace teamup\Controllers\messagerie;

use comfpl\controllers\BaseController;
use comfpl\views\PartialViewResult;

require_once 'models/userentity.php';
require_once 'service/userservice.php';
require_once 'service/sendgridservice.php';
require_once 'models/messageentity.php';
require_once 'service/messageservice.php';

require_once '../vendor/autoload.php';
/**
 * @Autorisation(access_control_mode=Autorisation::DENY_ANONYMOUS)
 */
class chatController extends BaseController
{
    public function index($model)
    {
        $model->title = "Teamup - Chat";
        return $this->View($model, "index");
    }
    
    public function sendoffline($model) {
        $userv = new \UserService();
        $list = $userv->getuserlist();
        
        $sender = "";
        $to = "";
        foreach($list as $user) {
            if($user->utilisateur_nom==\FPLGlobal::get_user_identity()->display_name) 
                $sender = $user->utilisateur_email;
            
            if($user->utilisateur_nom==$model->attendee)
                $to = $user->utilisateur_email;    
        }
        
        $message = $model->message;
        $sendgrid = new \SendGridService();
        $sendgrid->sendmessage($sender, $to, "message offline", $message);
        
        $view_source = "Message envoy&eacute; offline";
        return new PartialViewResult($view_source);
    }
    
    public function mongotest($model) {
        $client = new \MongoDB\Client("mongodb://localhost:27017");
        $collection = $client->teamup->chat;
        $list = $collection->find();
        
        $data = "";
        foreach ($list as $entry) {
            $data .= $entry['_id'] . " : " . $entry['from'] . " " .
                $entry['attendee'] . " " .
                $entry['message'] . " " .
                "<br>";
        }
        
        $model->data = $data;
        return $this->View($model,"mongotest");
    }
    
    public function filestreamtest($model)
    {
        return $this->View($model,"filestreamtest");
    }
    
    public function recordmessage($model) {
        $msg = new \MessageEntity();
        $msg->from = \FPLGlobal::get_user_identity()->display_name;
        $msg->attendee = $model->attendee;
        $msg->message = $model->message;
        $msg->date = date("d/m/yy H:i:s");
        
        $mdb = new \MessageService();
        $mdb->recordMessage($msg);
        
        return new PartialViewResult("");
    }
    
    public function testrtb($model) {        
        return $this->View($model,"testrtb");
    }
}
?>