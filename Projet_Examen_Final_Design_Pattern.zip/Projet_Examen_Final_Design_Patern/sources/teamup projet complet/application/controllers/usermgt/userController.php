<?php
namespace teamup\Controllers\usermgt;

use comfpl\controllers\BaseController;
require_once 'models/loginmodel.php';

/**
 * @Autorisation($access_control_mode=Autorisation::ALLOW_ALL | Autorisation::DENY_ANONYMOUS)
 * @author guerin
 *
 */
class userController extends BaseController
{
    function Login($view_model) {
        // transtypage du view_model en loginModel
        $model = \Automapper::map($view_model, new \ReflectionClass("\loginModel"));
        
        if ($this->is_post()) {
            // v�rifie si les saisies respectent les r�gles indiqu�es par annotation
            $this->validate_model($model);
            if(! $this->is_model_valid) {
                return $this->View($model,"login");
            }
            
            // v�rifie les cr�dits utilisateurs
            if(! \Authentication::authenticate($model->login, $model->pwd)) {
                \FPLGlobal::$view_bag->message="Echec &agrave; la connexion";
                return $this->View($model,"login");
            }
            
            // l'utilisateur est connect�
            return $this->Redirect(\FPLGlobal::$default_route);
        }
        
        return $this->View($model,"login");
    }
    
    function logout($model) {
        \Authentication::logout();
        return $this->View(new \loginModel(),"login");
    }
}