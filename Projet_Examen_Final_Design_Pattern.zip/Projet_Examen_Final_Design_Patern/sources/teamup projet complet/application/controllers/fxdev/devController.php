<?php
/*
 * devController.php
 */
namespace teamup\Controllers\fxdev;

use comfpl\controllers\BaseController;
require_once 'service/messageservice.php';


/**
 * @DIComponent(field_names="m_service",class_names="\MessageService")
 */
class devController extends BaseController
{
    /**
     * Instanci� par injection de d�pendance
     * @var \MessageService
     */
    public $m_service;
    
    public function ditest($model) {
        \TraceListener::write_message("dans action ditest");
        $model->guid = $this->m_service->new_guid();
        return $this->View($model,"ditest");
    }
    
    public function scripttest($model) {
        $vs = new \ViewScript();
        $vs->set_view_source_from_file(__DIR__ . "/../../views/fxdev/table.html");
        
        $vs->view_context = array("q1" => 500, "q2" => 1200, "q3" => 1350, "q4"=> 2000);
        $model->table = $vs->render_view();
        return $this->View($model,"scripttest");
    }
}
?>