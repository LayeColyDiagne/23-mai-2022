<?php
/*
 * homeController.php
 */
namespace teamup\Controllers\recherche;

use comfpl\controllers\BaseController;

require_once 'models/messageentity.php';
require_once 'service/messageservice.php';

require_once '../vendor/autoload.php';
/**
 * @Autorisation(access_control_mode=Autorisation::DENY_ANONYMOUS)
 */
class rechercheController extends BaseController
{
    public function search($model) {
        $from = \FPLGlobal::get_user_identity()->display_name;
        
        $mdb = new \MessageService();
        $results = $mdb->search($from, $model->query);
        $model->results = $results;
        
        return $this->View($model,"search");
    }
}
?>