<?php
/*
 * demandeController.php
 */
namespace teamup\Controllers\demandes;

use comfpl\controllers\BaseController;
use comfpl\views\JsonResult;

require_once 'models/demandeviewmodel.php';
require_once 'models/demandeentity.php';
require_once 'service/typedemandeservice.php';
require_once 'service/demandeservice.php';
require_once 'service/userservice.php';

/**
 * @Autorisation(access_control_mode=Autorisation::DENY_ANONYMOUS)
 */
class demandeController extends BaseController
{
    public function index($model)
    {
        return $this->View($model, "index");
    }
    
    public function adddemande($view_model){
        $tdservice = new \TypeDemandeService();
        
        $vm = new \demandeViewModel();
        $vm->demande = new \demandeEntity();
        $vm->demande->demande_date_creation = date("d/m/Y");
        
        $vm->typeDemandelist = array();
        foreach($tdservice->gettypedemandelist() as $td) {
            $vm->typeDemandelist[$td->id_type_demande]=$td->type_demande_label;
        }
        
        /*
         * v�rifie les saisies
         */
        $model = \Automapper::map($view_model, new \ReflectionClass("\demandeEntity"));
        
        if ($this->is_post()) {
            $this->validate_model($model);
            if(! $this->is_model_valid) {
                $vm->demande = $model;
                return $this->View($vm,"adddemande");
            } else {
                /*
                 * enregistre dans la base
                 */
                $model->id_utilisateur="NULL";
                $demandeservice = new \DemandeService();
                $demandeservice->adddemande($model);
  
                /*
                 * retourne vers une nouvelle saisie de demande
                 */
                return $this->View($vm,"adddemande");
            }
        }
    
        return $this->View($vm, "adddemande");
    }
    
    /**
     * @Route(parameters="id-{id}")
     */
    public function editdemande($view_model) {
        $tdservice = new \TypeDemandeService();
        $demandeservice = new \DemandeService();
        $userservice = new \UserService();
        
        $vm = new \demandeViewModel();
        $vm->utilisateurlist = array();
        
        foreach($userservice->getuserlist() as $user) {
            $vm->utilisateurlist[$user->id_utilisateur]=$user->utilisateur_nom;
        }
        
        $vm->id = $view_model->id;
         
        $vm->typeDemandelist = array();
        foreach($tdservice->gettypedemandelist() as $td) {
            $vm->typeDemandelist[$td->id_type_demande]=$td->type_demande_label;
        }
        
        if ($this->is_post()) {
            $model = \Automapper::map($view_model, new \ReflectionClass("\demandeEntity"));
            
            $this->validate_model($model);
            if(! $this->is_model_valid) {
                $vm->demande = $model;
                return $this->View($vm,"editdemande");
            } else {
                /*
                 * enregistre dans la base
                 */
                $model->id_demande = $view_model->id;
                //$model->id_utilisateur="NULL";
                $demandeservice = new \DemandeService();
                $demandeservice->editdemande($model);
                $vm->demande = $model;
                
                /*
                 * retourne vers une nouvelle saisie de demande
                 */
                return $this->View($vm,"editdemande");
            }
        } else {
            $vm->demande = $demandeservice->getdemandebyid($vm->id);
            return $this->View($vm,"editdemande");
        }
    }
    
    /**
     * Obtient la liste pagin�e des demandes
     * @param int $page
     * @param int $limit
     * @return array
     */
    function getdemandedata($page=null,$limit=null,$name=null){
        $demandeservice = new \DemandeService();
        $p = $demandeservice->getlistdemandes($name);
        
        $r=array();
        if($page!=null && $limit!=null)
        {
            $start = ($page - 1) * $limit;
        } else {
            $start = 0;
            $limit = count($p);
        }
        for($i = $start; $i < $start + $limit && $i < count($p); $i++)
            $r[] = $p[$i];
    
        return array("records" => $r, "total" => count($p));
    }
    
    /**
     * @return \comfpl\views\JsonResult
     */
    public function listdemandedata($model) {
        $page = isset($model->page) ? $model->page : null;
        $limit = isset($model->limit) ? $model->limit : null;
        $name = isset($model->name) && ($model->name!='null') ? $model->name : null;
        
        $p = $this->getdemandedata($page,$limit,$name);
        $json_dde_list = json_encode($p);
        
        return new JsonResult($json_dde_list);
    }  
    
    public function listdemandes($model){
        \FPLGlobal::$view_bag->title='Teamup - Demandes';
        return $this->View($model,"listdemandes");
    }
}
?>