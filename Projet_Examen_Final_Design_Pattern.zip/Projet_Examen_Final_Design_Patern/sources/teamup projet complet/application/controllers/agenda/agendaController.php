<?php
/*
 * agendaController.php
 */
namespace teamup\Controllers\agenda;

use comfpl\controllers\BaseController;
use comfpl\views\JsonResult;
use comfpl\views\PartialViewResult;

require_once 'models/evenemententity.php';
require_once 'models/participantentity.php';
require_once 'models/agendaviewmodel.php';
require_once 'service/evenementservice.php';
require_once 'service/userservice.php';
require_once 'service/icsservice.php';

/**
 * @Autorisation(access_control_mode=Autorisation::DENY_ANONYMOUS)
 */
class agendaController extends BaseController
{
    public function index($model)
    {
        if(! $this->is_post()) {
            $dtstart = new \DateTime();
            $dtend = new \DateTime();
            $dtend->add(new \DateInterval("P1W"));
            
            $model->dtstart = $dtstart->format("d/m/Y");
            $model->dtend = $dtend->format("d/m/Y");
        }
        return $this->View($model,"index");
    }
    
    /**
     * Obtient la liste pagin�e des �venements
     * @param int $page
     * @param int $limit
     * @return array
     */
    function getevdata($page = null, $limit = null, $id_utilisateur = null, $dtstart = null, $dtend = null) {
        $evservice = new \EvenementService();
        if($id_utilisateur!=null)        
            $p = $evservice->evenement_get_from_dates_utilisateur($dtstart, $dtend, $id_utilisateur);
        else
            $p = $evservice->evenement_get_from_dates($dtstart, $dtend);
        
        $r=array();
        if($page!=null && $limit!=null)
        {
            $start = ($page - 1) * $limit;
        } else {
            $start = 0;
            $limit = count($p);
        }
        for($i = $start; $i < $start + $limit && $i < count($p); $i++)
            $r[] = $p[$i];
            
        return array("records" => $r, "total" => count($p));
    }
    
    /**
     * @return \comfpl\views\JsonResult
     */
    public function listevdata($model) {
        $page = isset($model->page) ? $model->page : null;
        $limit = isset($model->limit) ? $model->limit : null;
        $id_utilisateur = isset($model->id_utilisateur) && 
                    ($model->id_utilisateur!='null') && 
                    $model->id_utilisateur!='' ? $model->id_utilisateur : null;
        
        $dtstart = new \DateTime();
        $dtend = new \DateTime();
        $dtend->add(new \DateInterval("P1W"));
        
        if(!isset($model->dtstart))
            $model->dtstart = $dtstart->format("d/m/Y");
    
        if(!isset($model->dtend))    
            $model->dtend = $dtend->format("d/m/Y");
        
        $dtstart = $model->dtstart;
        $dtend = $model->dtend;
        
        $p = $this->getevdata($page,$limit,$id_utilisateur,$dtstart,$dtend);
        
        $json_dde_list = json_encode($p);
        
        return new JsonResult($json_dde_list);
    }  
    
    
    public function agendaadd($model)
    {
        $view_model = new \agendaviewmodel();
        
        $usersvc = new \UserService();
        foreach($usersvc->getuserlist() as $user) {
            $view_model->participants_items[$user->id_utilisateur]=$user->utilisateur_nom;
            
            // recherche l'utilisateur courant
            if($user->utilisateur_login==\FPLGlobal::get_user_identity()->login)
                $view_model->evenement->id_utilisateur=$user->id_utilisateur;
        }
        
        /*
         * v�rifie les saisies
         */
        $eemodel = \Automapper::map($model, new \ReflectionClass("\EvenementEntity"));
        
        if ($this->is_post()) {
            $this->validate_model($eemodel);
            if(! $this->is_model_valid) {
                $view_model->evenement = $eemodel;
                return $this->View($view_model,"agendaadd");
            } else {
                /*
                 * enregistre dans la base
                 */
                $eemodel->evenement_tstamp = date("d/m/Y H:i");
                
                $pe = array();
                foreach($model->participants_selected as $p) {
                    $par = new \ParticipantEntity();
                    $par->id_utilisateur = $p;
                    $pe[]=$par;
                }
                
                $eservice = new \EvenementService();
                $id = $eservice->evenement_add($eemodel,$pe);
                
                /*
                 * retourne vers le planning
                 */
                return $this->Redirect( \FPLGlobal::get_route_uri("agenda", "agenda", "agendaedit",array("id"=>$id)));
            }
        }
        
        return $this->View($view_model,"agendaadd");
    }
    
    /**
     * @Route(parameters="idev-{idev}")
     */
    public function sendmeeting($model) {
        $id_evenement = $model->idev;
        
        $eservice = new \EvenementService();
        $event = $eservice->evenement_get_by_id($id_evenement);
        
        $participants = $eservice->evenement_get_participant($id_evenement);
        
        $usersvc = new \UserService();
        $users = $usersvc->getuserlist();
        
        $organizer = "";
        $attendees = array();
        
        foreach($users as $user) {
            if($user->id_utilisateur==$event->id_utilisateur) 
                $organizer = \ICSService::format_organizer($user->utilisateur_nom,$user->utilisateur_email);
            
            foreach($participants as $part) {
                if($part->id_utilisateur == $user->id_utilisateur) {
                    $attendees[] = \ICSService::format_attendee($user->utilisateur_nom,$user->utilisateur_email);
                }
            }
        }
        
        $ics = new \ICSService(
            array("description"=>$event->evenement_description,
                "location"=>$event->evenement_location,
                "dtstart"=>$event->evenement_dtstart,
                "dtend"=>$event->evenement_dtend,
                "organizer" => $organizer,
                "attendees" => $attendees
            )    
        );
        
        $ics_content = $ics->to_string();
        
        header('Content-Type: text/calendar; charset=utf-8');
        header('Content-Disposition: attachment; filename=rdv.ics');
        
        return new PartialViewResult($ics_content);
    }
    
    /**
     * @Route(parameters="id-{id}")
     */
    public function agendaedit($model) {
        $view_model = new \agendaviewmodel();
        $eservice = new \EvenementService();
        
        $usersvc = new \UserService();
        foreach($usersvc->getuserlist() as $user) {
            $view_model->participants_items[$user->id_utilisateur]=$user->utilisateur_nom;
            
            // recherche l'utilisateur courant
            if($user->utilisateur_login==\FPLGlobal::get_user_identity()->login)
                $view_model->evenement->id_utilisateur=$user->id_utilisateur;
        }
        
        /*
         * v�rifie les saisies
         */
        $eemodel = \Automapper::map($model, new \ReflectionClass("\EvenementEntity"));
        
        if ($this->is_post()) {
            $this->validate_model($eemodel);
            if(! $this->is_model_valid) {
                $view_model->evenement = $eemodel;
                return $this->View($view_model,"agendaedit");
            } else {
                $eemodel->id_evenement = $model->id;
                /*
                 * enregistre dans la base
                 */
                $pe = array();
                foreach($model->participants_selected as $p) {
                    $par = new \ParticipantEntity();
                    $par->id_utilisateur = $p;
                    $pe[]=$par;
                }
                
                $eservice = new \EvenementService();
                $eservice->evenement_edit($eemodel,$pe);
                
                /*
                 * retourne vers le planning
                 */
                return $this->View($view_model,"Index");
            }
        } else {
            $view_model->evenement = $eservice->evenement_get_by_id($model->id);
            $pe = $eservice->evenement_get_participant($model->id);
            
            $view_model->participants_selected = array();
            foreach($pe as $p)
                $view_model->participants_selected[]=$p->id_utilisateur;
            
            return $this->View($view_model,"agendaedit");
        }    
    }
    
    public function testpicker($model) {
        return $this->View($model,"testpicker");
    }
}
?>