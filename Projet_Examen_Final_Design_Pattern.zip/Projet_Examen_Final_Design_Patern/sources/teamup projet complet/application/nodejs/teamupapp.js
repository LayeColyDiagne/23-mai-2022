/**
 * teamupapp.js
 */

var app = require('express')();
var server = require('http').createServer(app);
var io = require('socket.io').listen(server);
var ent = require('ent'); // Permet de bloquer les caractères HTML (sécurité équivalente à htmlentities en PHP)

app.get('/index', function (req, res) {
	  res.sendfile(__dirname + '/index.html');
	});

var users = {};
var userstatus = {};
var userhasmessages = {};
var userpendingmessages = {};

var chat = io
.of("/teamupchat")
.on('connection', function (socket) {
	console.log("Connexion");

	/*
     * set-status
     */
    socket.on('set-status', function (displayname, status) {
    	console.log("status de "+ displayname + " : " + status);
    	userstatus[displayname] = status;
    });
    
    /*
     * get-status
     */
    socket.on('get-status', function (displayname) {
    	var status = "offline"; // offline donotdisturb online
    	if(userstatus!=null && userstatus[displayname]!=null)
    		status = userstatus[displayname];
    	
    	console.log("status de "+ displayname + " : " + status);
    	socket.emit('get-status', status);
    });
    
    /*
     * has-message
     */
    socket.on('has-messages', function (displayname) {
    	var has_messages = false;
    	if(userhasmessages!=null && userhasmessages[displayname]!=null)
    		has_messages = userhasmessages[displayname];
    	
    	console.log("has-messages "+ displayname + " : " + has_messages);
    	socket.emit('has-messages', has_messages);
    });
    
    /*
     * get-pending-messages
     */
    socket.on('get-pending-messages', function () {
    	var pendingmessages = userpendingmessages[socket.displayname];
    	
    	console.log("get-pending-messages "+ socket.displayname + " : " + pendingmessages);
    	socket.emit('get-pending-messages', pendingmessages);
    	
    	userpendingmessages[socket.displayname] = null;
    });
	
	/*
     * private-message
     */
    socket.on('private-message', function (attendee, message) {
    	console.log("message de "+ socket.displayname + " pour " + attendee + " : " + message);
    	console.log("status de "+ attendee +" "+ userstatus[attendee]);
    	
        message = ent.encode(message);
        if(userstatus[attendee]=="offline" || users[attendee]==null) {
        	console.log(attendee + " offline ou non connecté");
        } else {
        	if(userstatus[attendee]=="online") {
        		if(users==null) {
        			console.log("users is null cas non prévu");
        			return;
        		}
        		users[attendee].emit('private-message', { attendee: attendee, displayname: socket.displayname, message: message});
        	} else {
        		console.log("do not disturb message non délivré");
        		if(userpendingmessages[attendee]==null)
            		userpendingmessages[attendee] = "";
            	
            	userpendingmessages[attendee] += message+ " ";
            	userhasmessages[attendee] = true;
            	
            	users[attendee].emit('has-messages', true);
        	}
        }
    });
	
    /*
     * join-chat
     */
    socket.on('join-chat', function(displayname) {
    	console.log("join-chat de " + displayname);
    	users[displayname] = socket;
    	
    	displayname = ent.encode(displayname);
        socket.displayname = displayname;
        socket.broadcast.emit('join-chat', displayname);
    });

    /*
     * send-message
     */
    socket.on('send-message', function (message) {
    	console.log("message de "+ socket.displayname + ":" + message);

        message = ent.encode(message);
        socket.broadcast.emit('send-message', {displayname: socket.displayname, message: message});
    });
});

server.listen(8080);
