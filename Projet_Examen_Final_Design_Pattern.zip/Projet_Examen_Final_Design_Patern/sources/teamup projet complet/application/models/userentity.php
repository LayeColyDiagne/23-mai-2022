<?php
/*
 * userentity.php
 */

class UserEntity {
    public $id_utilisateur;
    public $utilisateur_nom;
    public $utilisateur_login;
    public $utilisateur_pwd;
    public $utilisateur_email;
    public $utilisateur_creation;
}
?>