<?php
/*
 * participantentity.php
 */

class ParticipantEntity {
    public $id_evenement;
    public $id_utilisateur;
}
?>