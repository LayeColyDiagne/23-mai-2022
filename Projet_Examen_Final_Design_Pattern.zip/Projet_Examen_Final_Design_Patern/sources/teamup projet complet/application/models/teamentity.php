<?php
/*
 * teamentity.php
 */

class TeamEntity {
    public $id_equipe;
    public $equipe_nom;
}
?>