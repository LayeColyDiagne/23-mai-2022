<?php
/*
 * typedemandeentity.php
 */
class typeDemandeEntity {
    public $id_type_demande;
    public $type_demande_label;
}
?>