<?php

/*
 * agendaviewmodel
 */
require_once 'models/evenemententity.php';
require_once 'models/participantentity.php';

class agendaviewmodel {
    /**
     * 
     * @var EvenementEntity
     */
    public $evenement;
    
    /**
     * 
     * @var array ParticipantEntity
     */
    public $participants_items;
    
    /**
     * 
     * @var array
     */
    public $participants_selected;
    
    public function __construct() {
        $this->evenement = new EvenementEntity();
        $this->participants_items = array();
    }
}
?>