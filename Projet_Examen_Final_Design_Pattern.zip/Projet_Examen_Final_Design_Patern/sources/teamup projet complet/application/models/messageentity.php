<?php
/*
 * messageentity.php 
 */

class MessageEntity {
  public $from;
  public $attendee;
  public $message;
  public $date;
}

?>