<?php
/*
 * demandeentity.php
 */

class demandeEntity {
    public $id_demande;
    
    /**
     * @Required(error="L'objet est requis",property="demande_objet")
     * @var string
     */
    public $demande_objet;
    public $demande_texte;
    public $demande_date_creation;
    
    /**
     * @Required(error="La date d'echeance est requise",property="demande_date_echeance")
     * @Rexvalid(error="Format de date attendu dd-mm-yyyy",format="[0-9]{2}/[0-9]{2}/[0-9]{4}",property="demande_date_echeance")
     * @var string
     */
    public $demande_date_echeance;
    
    /**
     * @Required(error="Le type de demande est requis",property="id_type_demande")
     * @TypeNumeric(error="Le type de demande n'est pas numerique",property="id_type_demande")
     * @TypeInteger(error="Le type de demande  doit &ecirc;tre un entier",property="id_type_demande")
     * @var int
     */
    public $id_type_demande;
    public $id_utilisateur;
    
    public $utilisateur_nom;
}
?>