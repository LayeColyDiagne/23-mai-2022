<?php
/*
 * demandeviewmodel.php
 */

class demandeViewModel {
    /**
     * 
     * @var demandeEntity
     */
    public $demande;
    
    /**
     * 
     * @var typeDemandeEntity[]
     */
    public $typeDemandelist;
    
    /**
     * 
     * @var UserEntity[]
     */
    public $utilisateurlist;
}
?>