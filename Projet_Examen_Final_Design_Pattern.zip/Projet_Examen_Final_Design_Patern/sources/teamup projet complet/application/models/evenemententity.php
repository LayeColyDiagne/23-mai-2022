<?php
/*
 * evenemententity.php
 */

class EvenementEntity {
    public $id_evenement;
    public $evenement_tstamp;
    
    /**
     * @Required(error="La date de debut est requise",property="evenement_dtstart")
     * @Rexvalid(error="Format de date attendu dd/mm/yyyy hh:mn",format="[0-9]{2}/[0-9]{2}/[0-9]{4} [0-9]{2}:[0-9]{2}",property="evenement_dtstart")
     * @var string
     */
    public $evenement_dtstart;

    /**
     * @Required(error="La date de fin est requise",property="evenement_dtend")
     * @Rexvalid(error="Format de date attendu dd/mm/yyyy hh:mn",format="[0-9]{2}/[0-9]{2}/[0-9]{4} [0-9]{2}:[0-9]{2}",property="evenement_dtend")
     * @var string
     */
    public $evenement_dtend;
    public $evenement_uid;
    
    /**
     * @Required(error="L'objet est requis",property="evenement_subject")
     * @var string
     */
    public $evenement_subject;
    public $evenement_description;
    public $evenement_location;
    public $id_utilisateur;
}
?>