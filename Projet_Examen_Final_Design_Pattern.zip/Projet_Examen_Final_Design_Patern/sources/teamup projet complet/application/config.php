<?php 
/*
 * config.php
 * (C) 2019 BAG
 * Fichier de configuration g�n�ral
 */
    const CONFIG_DEV = 1;
    const CONFIG_PROD = 2;
    
    $current_config = CONFIG_PROD;
    
    switch($current_config) {
        case CONFIG_DEV:
            require_once 'config-dev.php';
            break;
        case CONFIG_PROD:
            require_once 'config-prod.php';
            break;
    }
?>