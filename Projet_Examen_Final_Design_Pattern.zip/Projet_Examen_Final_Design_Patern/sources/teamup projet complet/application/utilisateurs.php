<?php require_once 'config.php'; ?><?php require_once '../comfpl/main.php';?>
<?php 
    /*
     * utilisateurs.php
     */
    require_once 'service/userservice.php';
    
    $service = new UserService();
    
    if($_SERVER['REQUEST_METHOD']==='POST')
        $filtrenom = $_POST["filtrenom"];
    else 
        $filtrenom = null;
    
    $list = $service->getuserlist($filtrenom);
    
?><html>
<head>
<title>Team up - Utilisateurs</title>
<?php require_once 'phpinclude/commonmeta.php';?>
<?php require_once 'phpinclude/theme.php';?>
<?php FPLGlobal::render_bundle_css()?> 
<?php FPLGlobal::render_bundle_script()?>
</head>
<body>
	<?php require_once 'phpinclude/navbar.php';?>

    <div class="container">
    	<div class="row">
    		<div class="col">
    		   	<form action="utilisateurs.php" method="post" class="form-inline">
    	    		<input class="form-control" type="search"
    				placeholder="Nom" aria-label="Nom" name='filtrenom'>
    				<button class="btn btn-outline-success" type="submit">Rechercher</button>
    			</form>
    		</div>
    	</div>
    	<div class="row">
    		<div class="col">
    			<a href="adduser.php">Ajouter utilisateur</a>
    		</div>
    		<div class="col">
    			<a href="equipes.php">Equipes</a>
    		</div>
    	</div>
    	<div class="row">
    		<div class="col">
    		<table class="table">
    			<tr>
    				<td>ID</td>
    				<td>Nom</td>
    				<td>Email</td>
    			</tr>
    		
    		<?php 
    		foreach($list as $user) {
    		?>
    			<tr>
    				<td><?php echo $user->id_utilisateur?></td>
    				<td><?php echo $user->utilisateur_nom?></td>
    				<td><?php echo $user->utilisateur_email?></td>
    			</tr>
    		<?php 
    		}
    		?>
    		
    		</table>
    		</div>
    	</div>
    </div>
    
</body>
</html>