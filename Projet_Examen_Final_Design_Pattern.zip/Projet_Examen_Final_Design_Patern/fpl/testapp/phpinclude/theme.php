<!-- theme -->
<link rel="stylesheet"
	href="themes/<?php echo FPLGlobal::$theme; ?>/styles/master.css" />