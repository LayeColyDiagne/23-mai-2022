<?php
header('Location: home-home-index.do');
exit();
?>